const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* :  𝐵𝐼𝐸𝐿𝑍𝐼𝑁𝑁
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
*Status Bot:* *Online*
──────────────────

*AÍ SIM PAE, VOCÊ É UM MEMBRO VIP😎✋`
}
exports.cekvip = cekvip
